package com.Booking.VO;

import com.Booking.Domain.BookingDetails;

public class ResponseTemplateVO {
private BookingDetails bookingdetails;
private Movies movies;
public BookingDetails getBookingdetails() {
	return bookingdetails;
}
public void setBookingdetails(BookingDetails bookingdetails) {
	this.bookingdetails = bookingdetails;
}
public Movies getMovies() {
	return movies;
}
public void setMovies(Movies movies) {
	this.movies = movies;
}

public ResponseTemplateVO()
{
super();
}
public ResponseTemplateVO(BookingDetails bookingdetails, Movies movies) {
	super();
	this.bookingdetails = bookingdetails;
	this.movies = movies;
}
@Override
public String toString() {
	return "ResponseTemplateVO [bookingdetails=" + bookingdetails + ", movies=" + movies + "]";
}


}
