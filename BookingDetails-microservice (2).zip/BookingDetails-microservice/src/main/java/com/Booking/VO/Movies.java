package com.Booking.VO;


import javax.persistence.Column;




public class Movies {
	
	
	
	private Integer movieid;
	
	
	@Column(name="movie_title")
	private String title;

	
	@Column(name="movie_genre")
	private String genre;
	
	
	@Column(name="movie_language")
	private String language;
	
	public Movies()
	{
		super();
	}

	public Integer getMovieid() {
		return movieid;
	}

	public void setMovieid(Integer movieid) {
		this.movieid = movieid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public Movies(Integer movieid, String title, String genre, String language) {
		super();
		this.movieid = movieid;
		this.title = title;
		this.genre = genre;
		this.language = language;
	}

	@Override
	public String toString() {
		return "Movies [movieid=" + movieid + ", title=" + title + ", genre=" + genre + ", language=" + language + "]";
	}
	
}

